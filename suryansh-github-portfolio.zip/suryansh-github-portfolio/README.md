# Suryansh — Developer Portfolio

A responsive, single-page portfolio built with plain HTML, CSS and a small amount of JavaScript.
No build step, package manager, backend, API key or external service is required.

## Recommended: publish at the clean root address

For a portfolio address of `https://cx97fsm-hash.github.io/`, GitHub requires a repository
named exactly `cx97fsm-hash.github.io`.

1. Open https://github.com/new while signed in to GitHub.
2. Create a **Public** repository named `cx97fsm-hash.github.io`.
3. Do not add a README, licence or `.gitignore` during repository creation (the website package already includes its own README).
4. Open the new repository and choose **Add file → Upload files**.
5. Upload `index.html` and `.nojekyll` from this package, then commit to the `main` branch.
6. Open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select branch **main** and folder **/(root)**, then choose **Save**.
9. After the first deployment completes, visit `https://cx97fsm-hash.github.io/`.

## Alternative: use the existing profile repository

Your existing profile repository is `cx97fsm-hash/cx97fsm-hash`. If you upload the website
files to that repository and enable Pages for `main` / `/(root)`, the project-site address
will be `https://cx97fsm-hash.github.io/cx97fsm-hash/` (not the root address).

## Files

- `index.html` — complete website
- `.nojekyll` — tells GitHub Pages not to run Jekyll processing
- `README.md` — these deployment instructions

## Updating the portfolio

Edit `index.html` and commit the changes to the publishing branch. GitHub Pages will redeploy
the site after the commit is published.

## Security and privacy notes

- This is a static website. It has no admin panel, authentication system, database, API endpoints or contact form.
- There are no API keys, credentials or secrets in the site.
- Email uses a `mailto:` link; it opens the visitor's email application and does not send a form submission to a server.
- External links use `rel="noopener noreferrer"` where they open a new tab.
- Do not add passwords, API keys, private phone numbers, student IDs or other sensitive data to a public repository.
- GitHub Pages is public hosting. Keep personal and sensitive information out of the published repository.

## Portfolio content accuracy

Skills are presented as current learning areas, not expert certifications. The fraud-detection
project is identified as a student learning prototype, not a production financial system.
No work experience, internships, grades, awards or certifications have been invented.
